#include <iostream>
#include <cmath>
#include "mnewton.h"

using namespace std;


// Definition of functor class
class Functor
{
		public:	
		// ()-operator overloading to accept x-values and function and jacobian placeholders
		void operator ()(double x[], double f[], double p[])
		{
				// F(X)
	
				f[0] = 1 - cos(x[0]) - cos(x[1]);
				f[1] = 2*x[0] - x[1];
	
				// -J⁻1*F(X) == P
				p[0] = -(cos(x[0])+ cos(x[1]) - 1 + x[1]*sin(x[1]) - 2*x[0]*sin(x[1]))/(-sin(x[0])-2*sin(x[1]));
				p[1] = -(2*cos(x[0]) + 2*cos(x[1]) - 2 + 2*x[0]*sin(x[0]) - x[1]*sin(x[0]))/(-sin(x[0])-2*sin(x[1]));
		}
};


int main () {
	
		// Definition functor
		Functor func;
	
		// Two empty vectors for function values
		double f[2];
	
		// initial values
		double x1[] = {1,1};
		double x2[] = {2,2};

		// function calls to mnewt() 
		int n1 = mnewt(func,x1,f);
		int n2 = mnewt(func,x2,f);
	
		// printing results
		cout << "Number of iterations for starting values {1,1}: " << n1 << " \nRoot at: " << x1[0] << " " << x1[1] << endl;
		cout << "Number of iterations for starting values {2,2}: " << n2 << " \nRoot at: " << x2[0] << " " << x2[1] << endl;
}
