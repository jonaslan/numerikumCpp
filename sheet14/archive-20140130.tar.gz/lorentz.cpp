// Charged particles in a magnetic field
#include <fstream>
#include <iostream>
#include <cmath>
#include "helfer.h"

using namespace std;

class RKSolver
{

	double h;
	VecDoub k1,k2,k3,k4;
	

public:
	RKSolver(const double hIn) : h(hIn)
	{
		k1.resize(6);
		k2.resize(6);
		k3.resize(6);
		k4.resize(6);
	}

	template <typename T>
	void integrate(T& func,const double t, VecDoub& y)
	{
		VecDoub y1(6),y2(6),y3(6);
		func(t, y, k1);
		for (int i = 0; i < y.size(); ++i)
			y1[i] = y[i]+0.5*h*k1[i];
		func(t+0.5*h, y1, k2);
		for (int i = 0; i < y.size(); ++i)
			y2[i] = y[i]+0.5*h*k1[i];
		func(t+0.5*h, y2, k3);
		for (int i = 0; i < y.size(); ++i)
			y3[i] = y[i]+0.5*h*k3[i];
		func(t+0.5*h, y3, k4);			
		
		for (int i = 0; i < y.size(); ++i)
		{
			y[i] = y[i] + h*(1./6.*k1[i]+1./3.*(k2[i]+k3[i])+1./6.*k4[i]);
		}
	}
};

class Lorentz
{
	double B0;
public:
	VecDoub ystart;
	Lorentz() : B0(1.)
	{
		ystart.resize(6);
		// initial position
		ystart[0] = 0.;
		ystart[1] = 0.;
		ystart[2] = 0.;
		
		// initial velocity
		ystart[3] = 1./sqrt(2);
		ystart[4] = 0;
		ystart[5] = 1./sqrt(2);
	}
	
	void operator() (const double t, const VecDoub& y, VecDoub& dydt)
	{
		dydt[0] = y[3];
		dydt[1] = y[4];
		dydt[2] = y[5];
		dydt[3] = y[4]*B0;
		dydt[4] = -y[3]*B0;
		dydt[5] = 0.;
	}
};

int main ()
{
	ofstream file;
	file.open("lorentz.txt",ios::trunc);
	double stepsize = 0.01;
	RKSolver RKS(stepsize);
	Lorentz L;

	double t = 0.;
	const double tmax = 1000.;
	VecDoub y = L.ystart;
	double v0 = sqrt(y[3]*y[3]+y[4]*y[4]+y[5]*y[5]);
	
	file << "#t\tx\ty\tz" << endl;
	
	while (t < tmax && sqrt(v2) < 1.01)
	{
		
		file << t << "\t" << y[0] << "\t" << y[1] << "\t" << y[2] << "\t" << sqrt(v2) << endl;
		RKS.integrate<Lorentz>(L,t,y);
		t = t + stepsize;
		v2 = y[3]*y[3]+y[4]*y[4]+y[5]*y[5];
	}
	
}