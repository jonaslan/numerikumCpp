#include <iostream>
#include "helfer.h"
#include "odeint.h"
#include "stepperdopr853.h"
#include "stepperbs.h"

using namespace std;

class Lorentz
{
	double B0;
public:
	VecDoub ystart;
	Lorentz() : B0(1.)
	{
		ystart.resize(6);
		// initial position
		ystart[0] = 0.;
		ystart[1] = 0.;
		ystart[2] = 0.;
		
		// initial velocity
		ystart[3] = 1./sqrt(2);
		ystart[4] = 0;
		ystart[5] = 1./sqrt(2);
	}
	
	void operator() (const double t, const VecDoub& y, VecDoub& dydt)
	{
		dydt[0] = y[3];
		dydt[1] = y[4];
		dydt[2] = y[5];
		dydt[3] = y[4]*B0;
		dydt[4] = -y[3]*B0;
		dydt[5] = 0.;
	}
};


int main ()
{
	Lorentz L;
	Output out1(1000);
	Output out2(1000);
	const double tmax = 1e7;
	double atol = 1e-10;
	double rtol = 1e-10;
	double h1 = 0.01;
	double hmin = 0.;
	
	Odeint<StepperDopr853<Lorentz> > DoPrSolver(L.ystart, 0., tmax, atol, rtol, h1, hmin, out1, L);
	Odeint<StepperBS<Lorentz> > BSSolver(L.ystart, 0., tmax, atol, rtol, h1, hmin, out2, L);
	
	DoPrSolver.integrate();
	BSSolver.integrate();
	
	cout << out1.steps[0] << "\t" << out2.steps[0] << endl;
	
}