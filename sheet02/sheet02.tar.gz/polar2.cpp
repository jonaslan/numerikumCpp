#include<iostream>
#include<cmath>

using namespace std;

void cartesian2polar (const double x, const double y)
{
  double r,phi;	// cartesian coordinates
  const double cf = M_PI/180.0; //conversion factor

  
  r = sqrt(x*x+y*y);	// radius
  
  // atan2(y,x) returns arc tangent of y/x [taking signs into account to determine quadrant]
  // in brackets being the advantage of using the function
  
  phi = atan2(y,x);		// angle
  
  phi *= (1.0/cf);	// conversion to degrees
  
  // formatting to cartesian coordinates
  
  cout << "r: " << r << " || phi: " << phi << endl;
}


int main()
{
  
  cout << "Input x:\n";
  
  double x;
  
  // Now we check that the input is a number and not a char
	  
  while(!(cin >> x))
  {
	
	cin.clear(); //if keyboard input is not a number, cin.clear() empties the input from the keyboard
	cin.ignore(); // ignore and go further 
	cout << "NOT A NUMBER\n";
	}

  cout << "Input y:\n";
  
  double y;
	
  cin >> y;
	
  while(!(cin >> y))
  {
	
	cin.clear(); //if keyboard input is not a number, cin.clear() empties the input from the keyboard
	cin.ignore(); // ignore and go further 
	cout << "NOT A NUMBER\n";
	}
    
  
  
  // call of conversion function
  
  cartesian2polar(x, y);
  
}
