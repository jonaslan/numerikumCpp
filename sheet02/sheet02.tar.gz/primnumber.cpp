#include <iostream>
using namespace std;

int main(int argc, char **argv)
{
	int count = 1; // counts the number of prime numbers found
	const int begin=10000000,end=10000500; //interval of numbers within which we search for prime numbers
	
	for(int i = begin; i<= end; i++)
		{
			bool prime = true; //flag used to break the for loop  when is set to "false"
			
			// to check whether the number is prime, successive divisions are performed until it finds (or not) mod = 0
			for ( int divisor = 2; divisor <= i/2; ++divisor)
			{
				 if (i%divisor == 0)
				 {
					 prime = false;
					 break; //when a divisor is found, the number is not prime and the program carries on with next number
				 }
			}
			if (prime)
			 {
				 
				 cout << count << " " << i << endl;
				 ++count;
			 }
		}
	
	return 0;
}

