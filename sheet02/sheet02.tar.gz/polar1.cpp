#include<iostream>
#include<cmath>

using namespace std;

void polar2cartesian (const double r, const double phi)
{
  double x,y;	// cartesian coordinates
  
  x = r*cos(phi);
  y = r*sin(phi);
  
  // formatting to cartesian coordinates
  
  cout << "x: " << x << " || y: " << y << endl;
}


int main()
{
  const double conv_factor = M_PI/180.0;

  double r = -1.0;
  
  while (r < 0)
  {
  cout << "Input radius:\n";  
  cin >> r;
  }
  
  // reading and reduction of angle argument
  
  cout << "Input angle:\n";
  
  double angle;
  
  cin >> angle;
  
  // if angle > 360 -> mod 360, if < 0 -> mod 360 + 360
  
  if (angle > 360)
  {
    int factor = angle/360;
    angle -= factor*360;
  }
  else if (angle < 0)
  {
    int factor = angle/360;
    angle += (factor+1)*360; //angle = angle + (factor+1)*360
  }
  
  angle *= conv_factor;		// convert to radians
  
  // call of conversion function
  
  polar2cartesian(r,angle);
  
}