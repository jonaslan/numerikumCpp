#include<iostream>
#include<cmath>

using namespace std;

const static int len = 5; // Lenght of the array of coefficients (of the Taylor expansion)

// the function sinandcos evaluates the Taylor series of sine (up to 11th order) and cosine (up to 10th order) functions


void sinandcos (double x)
{
  // declaring coefficients of the Taylor expansion as an array
  

  const double sin_coeffs[] = {1., -1./6., 1./120., -1./5040., 1./362880., -1./39916800.};
  const double cos_coeffs[] = {1., -1./2., 1./24., -1./720., 1./40320., -1./3628800.};
  
  
  // Initialization of variables used for the loop.
  
  double sinx = 0, cosx = 0, xsq;
  
  x *= (M_PI/180.0); // conversion to radians
  
  xsq = x*x;
  
  // The evaluation of the mathematical expression is performed inside-out (after taking common factor)
  
  sinx = sin_coeffs[4]+xsq*sin_coeffs[5];
  cosx = cos_coeffs[4]+xsq*cos_coeffs[5];
  
  for (int i = 3; i >= 0; --i)
  {
	cout << sinx << " " << cosx << endl; // printing out evolution of the calculation (control)
    sinx *= xsq;
    sinx += sin_coeffs[i];
    cosx *= xsq;
    cosx += cos_coeffs[i];
    
  }
  sinx *= x;    //final multiplication is needed for the sine
  
  //print out final result
  cout << "sin(x) = " << sinx << " || " << "cos(x) = " << cosx << endl;
	
}


int main()
{
  
  //Ask for input angle
  cout << "Enter x: \n";
  double x;
  cin >> x;
  
  // Call to function that approximates sine and cosine and prints the result
  sinandcos(x);
  
 
  cout <<"Vergleich mit cmath-Bibliothek"<< endl;
  
  cout<< "sinus :"<< sin(x*M_PI/180.0) << endl;
  cout<< "cosinus :"<< cos(x*M_PI/180.0)<< endl;
  
  // We have compared the results of our approximation with those of c-math library
  //For angle x=pi/2, the results are copied below:
  /* sin(x) = 1 || cos(x) = -4.64766e-07
	Vergleich mit cmath-Bibliothek
	sinus :1
	cosinus :6.12323e-17 */
	
	// We can see that the approximation given by c-math is closer to zero 
	//(then more accurate) because of higher-order terms in the power series

  
}
