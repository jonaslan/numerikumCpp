#include <iostream>
#include <cmath>

using namespace std;

// Definition of the Vektor class
class Vektor
{	
	// values declared as private. Since the add and scalar methods are declared inside the class 
	// these variables do not have to be public.
	double x, y, z;	
	public:
	
	// print function, inserts vector components into output stream
	friend ostream& operator<< (ostream& out, const Vektor& v)
	{
			out << "[ " << v.x << ", "<< v.y << ", " << v.z << " ]";
			return out;
	}
	
	// Constructor #1, no input values -> null vector
	Vektor() {
		x = 0;
		y = 0;
		z = 0;
	}
	// constructor #2, values are set
	Vektor(double xin, double yin, double zin)
	{
		x = xin;
		y = yin;
		z = zin;
	}
	
	// Absolute value (length of the vector)
	double absValue()
	{
		return sqrt(x*x+y*y+z*z);
	}
	
	// scalar product of two vectors, one taken by reference by the other
	double scalar(const Vektor& b)
	{
		return x * b.x + y * b.y + z * b.z;
	}

	// add function, one vector takes another by reference and creates a sum vector 
	Vektor add(const Vektor& b)
	{
		Vektor c(x+b.x,y+b.y,z+b.z);
		return c;
	}
};


int main()
{
	// Instantiate initial vectors
	Vektor a(1.,2.,3.);
	Vektor b(2.,2.,2.);
	
	// Null vector instantiation
	Vektor z;
	
	// add null vector to a -> nothing happens
	a = a.add(z);
	
	// print vectors
	cout << "Vector a: " << a << endl;
	cout << "Vector b: " << b << endl;
	
	// scalar product of a and b
	cout << "Scalar product\t" << a.scalar(b) << endl;
	
	// to vector a, add b and output as vector c
	Vektor c = a.add(b);
	
	// print sum and absolute value
	cout << "Sum of vectors\t" << c << endl; 
	cout << "Absolute value of sum: " << c.absValue() << endl;
	return 0;
}
