#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;


class Tanh
{
	double a;
	
	public:
	
	Tanh()		// Constructor
	{
		a = 2.;		// multiple definition
	}
	
		double operator() (double x)	// ()-operator overloading, checking input value and returning limit if necessary
		{
			if (abs(x) > 1e-15){
			return tanh(a * x)/x;
			} else {
			return 1;
			}
		}
	};
	
	int main(){
		
		Tanh t;			// tanh object instantiation
		ofstream file;	// output object instantiation
		
		file.open("values.txt",ios::trunc);	// create file, if file exists -> erase previous content of file
		
		// boundaries
		const double max = 10.;		
		const double min = -6.;
		
		// auxiliary variable
		double v;
		
		// number of steps and stepsize
		const int steps = 250;
		const double stepsize = (max-min)/(steps-1);
		
		// 250 steps
		for (double i = 0; i < steps; ++i)
		{
			v = min + i*(stepsize);
			file << v << "\t" << t(v) << endl;		// writing to file
		}
		file.close();		// closing file
		return 0;
	}
	
		
		
