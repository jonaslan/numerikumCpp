#include <iostream>

using namespace std;

class Cluster
{
	// cluster characteristics 
	double mtotal;
	double mstars;
	double eps;
	
	public:
	
	// Constructor
	Cluster(double mt, double ms, double eff)
	{
	mtotal = mt;
	mstars = ms;
	eps = eff;
	}
	
	// starform function, increases mass contained in stars by (efficiency * free mass) every timestep
	void starform()
	{
	mstars += eps * (mtotal - mstars);
	}
	
	// prints total mass and mass contained in stars
	void printmass()
	{
	cout << mtotal << "\t" << mstars << endl;
	}
	
	// function for calculating the percentage of mass in stars
	double calculate()
	{
		return mstars/mtotal*100.;
	}
};

int main()
{
	
	// cluster objects get instantiated
	Cluster c1(1e8, 0., 0.3), c2(1e9, 0., 0.1);
	
	
	// 15 timesteps
	for (int i = 1; i <=15; i++)
	{
	// star formation
	c1.starform();
	c2.starform();
	
	// print masses
	cout << "cluster 1:\t ";
	c1.printmass();
	cout << "cluster 2:\t ";
	c2.printmass();
	}
	
	// Mass change percentage
	cout << "\n percentage mass change cluster 1: " << c1.calculate()  << "%" << endl;
	cout << "\n percentage mass change cluster 2: " << c2.calculate() << "%" << endl;	
	return 0;
}
	
	
	
